/**
 * This class represents a ship. A ship can be in one of three states:
 * <ul>
 * <li><b>CAPTURING</b>: The ship is able to fly about the playing area. It
 * can pick up the opponent's flag by colliding with it. The ship is visible
 * and collidable and can fire bullets.</li>
 * <li><b>SCORING</b>: The ship is carrying a flag. The player can score by
 * flying over the player's base. The ship is visible and collidable. It cannot
 * fire a bullet until it has dropped the flag (thereby entering the CAPTURING
 * state).</li>
 * <li><b>DESTROYED</b>: The ship has been destroyed. Its position is constant
 * and its rotation is zero. It is visible but not collidable.</li>
 * </ul>
 * A ship has two timers: the firing timer and the respawn timer. The firing
 * timer is set each time the ship fires; the ship cannot fire again until the
 * timer has expired. For the purposes of resetting the firing timer, dropping
 * the flag by attempting to fire counts as firing, even though no bullet is
 * actually fired. The respawn timer is set when the ship is destroyed. When it
 * expires, the ship is respawned with its starting position and rotation and in
 * the Capturing state.
 */
public class Ship extends GameObject {
	/**
	 * Indicates a ship that has not picked up a flag.
	 */
    public static final int CAPTURING  = 1;
    
    /**
     * Indicates a ship that has picked up a flag.
     */
    public static final int SCORING    = 2;
    
    /**
     * Indicates a ship that has been destroyed.
     */
    public static final int DESTROYED  = 3;

    // Declare additional class variables here if necessary. Remember that all
	// class variables you add must be declared private!

    /**
     * Creates a new ship. The ship's position and rotation are set to the
     * provided coordinates and rotation. The ship's speed is set to zero. The
	 * ship's state is {@code Ship.CAPTURING}, the image is
	 * {@code Config.SHIP_CAPTURING_IMG[playerID]}, and it is made visible and
	 * collidable. The firing timer and respawn timer are created (but not
	 * started).
     * 
     * @param game the parent game
     * @param playerID the ID of the ship's owning player
     * @param x the ship's initial x position.
     * @param y the ship's initial y position.
     * @param rotation the ship's initial rotation.
     */
    public Ship(Game game, int playerID, double x, double y, double rotation) {
        super(game, new Position(x, y), Config.SHIP_RADIUS);
    	// TODO

		// Set the image using setImage() and make the ship visible using
		// setVisible().

		// Set the rotation of the ship using setRotation().
    }

 	/**
	 * Rotates the ship by the specified angle. That is, this method adds its
	 * argument to the ship's current rotation. This method does not rotate the
	 * ship if the ship is destroyed.
	 *
	 * @param angle the angle of rotation in radians
	 */
	public void rotate(double angle) {
		// TODO
		
		// To rotate the ship, you must add the angle parameter to the
		// ship's current rotation.  You can get the ship's current rotation
		// by calling getRotation().
	}

	/**
	 * Adds the specified change in velocity to the ship's speed. This method
	 * guarantees that the ship's speed is within the range 
	 * {@code -Config.SHIP_MAX_SPEED} to {@code Config.SHIP_MAX_SPEED}.
	 *
	 * @param speedDelta the change in speed in pixels/sec
	 */
	public void accelerate(double speedDelta) {
		// TODO

		// Add speedDelta to the ship's current speed.

		// If the new speed is outside the allowed range, set the ship's speed
		// to the nearest allowed value.

		// Set the ship's speed by calling setSpeed().
	}

    /**
     * Called automatically at each game tick to handle the ship's game logic.
     * If the ship is not in the Destroyed state, updates the ship's position
     * and destroys the ship if it has collided with the boundary of the playing
     * field. Otherwise, if the ship is destroyed and the respawn timer has
     * expired, respawns the ship in the Capturing state at its original
     * position and with its original speed and rotation.
     * <p>
     * Do NOT call this method from your code! It is called automatically each
     * tick.
     * </p>
     *
     * @param deltaTime the time since the previous tick in seconds.
     */
    @Override
    public void update(double deltaTime) {
    	// TODO
    	
        // If the ship is destroyed, check if the respawn timer has expired, and
        // if so respawn the ship.

        // Otherwise, if the ship is not destroyed, update its position.

        // A ship must be destroyed if it collides with the boundary of the
        // playing field. The ship collides with the playing field if its
		// position goes beyond any edge of the playing field (i.e. if the X
		// coordinate is less that 0 or more than Config.GAME_WIDTH and
		// similarly for the Y coordinate and the height of the playing field).

    }

    /**
     * Returns the ID of the owning player of this ship: one of {@code
	 * Config.PLAYER1} or {@code Config.PLAYER2}.
     * 
     * @return the ID owning player
     */
    public int getPlayerID() {
    	// TODO
    	
    	return -1;
    }
    
    /**
     * Returns the ship's current state: one of {@code Ship.CAPTURING},
     * {@code Ship.SCORING}, or {@code Ship.DESTROYED}.
     * 
     * @return the ship's state.
     */
    public int getState() {
    	// TODO
    	
    	return -1;
    }

    /**
     * Handles a collision with a ship. This method is called automatically by
	 * the game at each tick that this ship and another ship collide. This
	 * method destroys the ship.
	 * <p>
     * Do NOT call this method from your code! It is called automatically when
     * this ship collides with another ship.
     * </p>
     */
    public void collideShip() {
    	// TODO
    	
	}

    /**
     * Handles a collision with an asteroid. This method is called automatically
     * by the game at each tick that this ship collides with an asteroid. This
	 * method destroys the ship.
	 * <p>
     * Do NOT call this method from your code! It is called automatically when
     * this ship collides with an asteroid.
     * </p>
     */
	public void collideAsteroid() {
		// TODO
		
	}

    /**
     * If this ship is in the Scoring state, returns the flag this ship is
     * carrying. If the ship is not in the Scoring state, returns {@code null}.
     *
     * @return the {@link Flag} this ship is carrying, or null.
     */
    public Flag getFlag() {
        // TODO

        return null;
    }

    /**
     * Handles a collision with a flag. This method is called automatically by
     * the game at each tick that this ship collides with a flag. This method
     * checks whether the flag can be picked up by this ship. If so, it picks it
     * up, saving a reference to the flag and changing the ship's state to
     * SCORING.
     * <p>
     * Do NOT call this method from your code! It is called automatically when
     * this ship collides with a flag.
     * </p>
	 * 
     * @param flag the {@link Flag} this ship collided with.
     */
	public void collideFlag(Flag flag) {
		// TODO
		
		// If this ship collided with a flag that can be picked up, as
		// determined by the flag's canBePicked() method, save a reference in
		// this ship object, notify the flag that it has been picked up, and
		// put this ship in the Scoring state.

	}
   
	/**
	 * Handles a collision with a base. This method is called automatically by
     * the game at each tick that this ship collides with a base. If the ship
	 * is in the Scoring state and the flag can be scored at this base, this
	 * method scores the flag and the ship returns to the Capturing state.
     * <p>
     * Do NOT call this method from your code! It is called automatically when
     * this ship collides with a base.
     * </p>
	 * 
	 * @param base the {@link Base} this ship collided with.
	 */
	public void collideBase(Base base) {
		// TODO
		
		// If the ship is in the Scoring state and the ship can score a flag at
        // this base, call the game's score() method, the flag's reset() method,
        // and put the ship in the Capturing state.

    }

	/**
	 * Fires a bullet if this ship is able to fire. If the ship is destroyed or
	 * the firing timer has not expired yet, this method does nothing. If the
	 * ship is in the Scoring state, drops the flag, resets the firing timer,
	 * and enters the capturing state. Otherwise, creates a new bullet object
	 * and adds it to the game.
	 */
    public void fire() {
    	// TODO
    	
    	// If the ship is destroyed or the timer hasn't expired, it can't fire
    	// and this method does nothing.
    	
        // Otherwise, set the firing timer.

        // If the ship is in the Capturing state, first calculate the position
		// of the new bullet. Get a copy of the ship's position, then move that
		// position in the direction of the ship's rotation using the
		// moveInDirection() method provided by Position objects. The distance
		// moved should be equal to the ship's radius plus the bullet's radius.
        // Finally, create the new bullet and add it to the game.

		// If the ship is in the Scoring state, drop the flag and enter the
		// Capturing state without firing a bullet. 

    }

    /**
     * Handles a collision with a bullet. This method is called automatically by
	 * the game at each tick that this ship collides with a bullet. This method
     * destroys the ship.
     * <p>
     * Do NOT call this method from your code! It is called automatically when
     * this ship collides with a bullet.
     * </p>
     */
	public void collideBullet() {
		// TODO
		
	}
}
