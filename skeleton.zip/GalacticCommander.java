import java.io.IOException;

/**
 * This class is the program entry point and implements game initialization,
 * input handling, and scoring. It keeps track of each player's ship, base,
 * flag, and score. This is where you must add code to create game objects and
 * add them to the game, handle input, and keep track of the score.
 */
public class GalacticCommander extends Game {
    // Declare additional class variables here if necessary. Remember that all
	// class variables you add must be declared private!

	/**
	 * Creates a new instance of the game. This method is completed for you.
	 * <p>
	 * DO NOT add, change, or remove code here!
	 * </p>
	 * 
	 * @throws IOException
	 */
	public GalacticCommander() throws IOException {
		super();
	}

	/**
	 * This is the game's main method.  It creates a new game object,
	 * initializes the game, and starts the game loop. It is completed for you.
	 * <p>
	 * DO NOT add, change, or remove code here!
	 * </p>
	 * @param args
	 * @throws IOException
	 */
	public static void main(String args[]) throws IOException {
		// THIS METHOD HAS BEEN COMPLETED FOR YOU. DO NOT ADD CODE HERE.
		
		// Create a new game
		Game game = new GalacticCommander();
		// Initialize the game
		game.initGame();
		// Start the game
		game.runGameLoop();
	}

	/**
	 * Initializes the game. Creates each of the ships, flags, bases, and
	 * asteroids and adds them to the game. Also initializes the player's
	 * scores.
	 */
	@Override
	void initGame() {
		// TODO

		// 0. Create and add asteroids (complete)
		for (int i = 0; i < Config.ASTEROID_POSITIONS.length; i++) {
			Asteroid a = new Asteroid(this, Config.ASTEROID_POSITIONS[i], i);
			addGameObject(a);
		}

		// 1. Create one Base object for each player. The first argument to the
		//    constructor is the parent Game, which is this. The second argument
		//    is the PlayerID, which should be one of Config.PLAYER1_ID or
		//    Config.PLAYER2_ID. The last two arguments give the position of the
		//    base, which should be set to Config.BASE_PLAYER1_X,
		//    Config.BASE_PLAYER1_Y, and so on.

		// 2. Add one ship for each player to the game. The first four arguments
		//    to the Ship constructor are analogous to the argument for bases.
        //    The fifth argument is the initial rotation of the ship, which
        //    should be set to Config.SHIP_PLAYER1_ROTATION or
        //    Config.SHIP_PLAYER2_ROTATION, as appropriate.

		// 3. Add one flag for each player to the game. The initial x and y
		//	  coordinates are the same as the corresponding base. That is,
		//	  player 1's flag starts at the exact same position as player 1's
		//	  base.

		// 4. Initialize the score displays. Each player's score should be set
		//    to zero. Player1's score should be displayed in
		//    Graphics.LEFT_PANEL using getGraphics().setPanelText(). Player2's
		//    score should be displayed in Graphics.RIGHT_PANEL. You may
		//    optionally set the font, font size, and font color if you like.

	} // End of initGame() 

	/**
	 * Handles keyboard input at each game tick. This method checks if each of
	 * the control keys is pressed, and if so calls the corresponding method of
	 * the appropriate player's ship.
	 * 
	 * @param deltaTime the time since the previous tick in seconds.
	 */
	@Override
	void handleInput(double deltaTime) {
		// TODO

		// Handle rotation for Player 1. If the A key is pressed, rotate player
		// 1's ship counter-clockwise (CCW). If the D key is pressed, rotate
        // player 1's ship clockwise (CW). If both A and D are pressed, the ship
        // should not rotate. Remember that the direction of rotation (CW or
        // CCW) is given by the sign of the angle: positive angles are CW,
        // negative  angles are CCW. To calculate how much to rotate the ship,
        // you must multiply the rotation speed (given by
        // Config.SHIP_ROTATE_SPEED) by deltaTime.

		// Handle acceleration for Player 1. If the W key is pressed, increase
        // the speed of player 1's ship. If the S key is pressed, decrease the
        // speed. To calculate how much to change the speed, you must multiply
        // the ship's acceleration (given by Config.SHIP_ACCELERATION) by
        // deltaTime.

		// Handle rotation for Player 2 

		// Handle acceleration for Player 2 

		// Handle firing for Player 1. If the left shift key is pressed, call
        // player 1's ship's fire() method.

		// Handle firing for Player 2 

	} // End of handleInput()

	/**
	 * Increments the score for the indicated player. If the player has scored
	 * {@code Config.POINTS_TO_WIN} points, this method ends the game by
	 * calling {@code endGame()} and sets the text in {@code
	 * Graphics.CENTER_PANEL} to a message indicating which player won.
	 * 
	 * @param playerID the player who scored.
	 */
	@Override
	public void score(int playerID) {
		// TODO

		// Increment the score for the indicated player.

		// Check if the game is over; if so, set an appropriate victory message
		// in Graphics.CENTER_PANEL and end the game. 

	} // End of score()
}
